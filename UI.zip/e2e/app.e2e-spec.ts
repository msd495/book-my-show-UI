import { BookMyShowPage } from './app.po';

describe('book-my-show App', function() {
  let page: BookMyShowPage;

  beforeEach(() => {
    page = new BookMyShowPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
