import {Component} from '@angular/core';

@Component({
    selector: 'app-my-movies',
    templateUrl : 'movie.component.html',
    styleUrls : ['movie.component.css']
})

export class MovieComponent {
    title= 'Man of the steel';
    DateandTime = 'Sun 8 Sept - 10:15PM';
    screen= '3';
    row= 'F';
    seat= '21,22';
}
